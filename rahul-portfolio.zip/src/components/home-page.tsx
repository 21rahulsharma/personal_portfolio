import { Link } from "@tanstack/react-router";
import { experience, profile, toolkit, works } from "@/data/content";
import { SiteFrame } from "@/components/site-frame";

export function HomePage() {
  const [search, agents, mcp, evaluation] = works;

  return (
    <SiteFrame>
      <main className="page">
        <section className="wrap hero">
          <h1 className="display">
            Hello, I build
            <br />
            <span className="mark">agentic systems</span> that carry
            <br />
            <em>intent</em> <span className="flourish">✻</span> into <em>outcomes</em>{" "}
            <span className="flourish">✻</span>
          </h1>
          <p className="lede">
            {profile.role}. {profile.bio}
          </p>
          <a className="chip" href="#work">
            Selected systems
          </a>
        </section>

        <section className="wrap mosaic" id="work">
          <div className="col">
            <Link
              to="/work/$slug"
              params={{ slug: search.slug }}
              className="shot ratio-a"
              aria-label={search.title}
            >
              <img className="cover" src={search.cover} alt={search.alt} />
              <div className="float-ui ui-search">
                <div className="ui-kicker">Conversational search</div>
                <p className="ui-q">Which clause still governs after the vendor changes terms?</p>
                <div className="ui-row">
                  <span>3 sources · grounded</span>
                  <span>Ragas</span>
                </div>
              </div>
              <span className="shot-cap">
                <span>{search.title}</span>
                <span>{search.year}</span>
              </span>
            </Link>

            <Link
              to="/work/$slug"
              params={{ slug: mcp.slug }}
              className="shot ratio-c"
              aria-label={mcp.title}
            >
              <img className="cover" src={mcp.cover} alt={mcp.alt} />
              <div className="wordmark">
                <span className="tick" />
                <strong>MCP</strong>
                <em>custom servers</em>
              </div>
              <span className="shot-cap">
                <span>{mcp.title}</span>
                <span>{mcp.year}</span>
              </span>
            </Link>
          </div>

          <div className="col">
            <Link
              to="/work/$slug"
              params={{ slug: agents.slug }}
              className="shot ratio-b"
              aria-label={agents.title}
            >
              <img className="cover" src={agents.cover} alt={agents.alt} />
              <span className="studio-tag">LangGraph · pause when it matters</span>
              <span className="shot-cap">
                <span>{agents.title}</span>
                <span>{agents.year}</span>
              </span>
            </Link>

            <Link
              to="/work/$slug"
              params={{ slug: evaluation.slug }}
              className="shot ratio-d"
              aria-label={evaluation.title}
            >
              <img className="cover" src={evaluation.cover} alt={evaluation.alt} />
              <div className="float-ui ui-eval">
                <div className="ui-kicker">Evaluation studio</div>
                <div className="metrics">
                  <div className="metric">
                    <b>Hold</b>
                    <span>Faithfulness</span>
                  </div>
                  <div className="metric">
                    <b>Diff</b>
                    <span>Every change</span>
                  </div>
                  <div className="metric">
                    <b>Trace</b>
                    <span>LangSmith</span>
                  </div>
                </div>
                <div className="bars">
                  <div className="bar alt">
                    <i />
                  </div>
                  <div className="bar mid">
                    <i />
                  </div>
                  <div className="bar low">
                    <i />
                  </div>
                </div>
              </div>
              <span className="shot-cap">
                <span>{evaluation.title}</span>
                <span>{evaluation.year}</span>
              </span>
            </Link>
          </div>
        </section>

        <section className="wrap">
          <div className="section-title">
            <Spark />
            <h2>
              Recent
              <br />
              <em>path</em>
            </h2>
          </div>
          <div className="rows">
            {experience.map((item) => (
              <div className="row" key={item.role}>
                <span>{item.role}</span>
                <span>{item.org}</span>
                <span>{item.when}</span>
              </div>
            ))}
            {toolkit.map((item) => (
              <div className="row" key={item.label}>
                <span>{item.label}</span>
                <span>{item.value}</span>
                <span>{item.note}</span>
              </div>
            ))}
          </div>

          <p className="pixel-label">
            <i /> More I build
          </p>

          <div className="loose">
            <div className="phone-row">
              <article className="phone">
                <div className="phone-top">
                  <span className="blob" aria-hidden="true">
                    <Dot light={false} />
                  </span>
                  <p>A question changes shape until the sources agree. Then the answer is allowed to be short.</p>
                </div>
                <div className="art" />
                <div className="phone-actions">
                  <b>Ground it</b>
                </div>
              </article>
              <article className="phone dark">
                <div className="phone-top">
                  <span className="blob" aria-hidden="true">
                    <Dot light />
                  </span>
                  <p>The agent waits. You approve the step that spends money, access, or trust.</p>
                </div>
                <div className="art" />
                <div className="phone-actions">
                  <b>Approve</b>
                  <s aria-hidden="true">↑</s>
                </div>
              </article>
            </div>

            <Link to="/work/$slug" params={{ slug: "evaluation" }} className="frame thermal shot" aria-label="Evaluation traces">
              <img src="/images/thermal.jpg" alt="Abstract heat map of evaluation traces" />
            </Link>

            <article className="sage">
              <img src="/images/moss-phone.jpg" alt="A phone growing moss around a patch of sky" />
              <p>Stay with the work.</p>
            </article>

            <div className="frame triptych">
              <img src="/images/triptych.jpg" alt="Three studies: static, ink mountains, and a brush mark" />
            </div>

            <div className="collage-wrap">
              <img src="/images/collage.jpg" alt="Paper collage of graph paper, tape, and a black brush stroke" />
            </div>
          </div>

          <section className="story">
            <h2>Built to be checked</h2>
            <div>
              <p>
                {profile.bio} The point is not a larger model. It is a system a team can run, trace, and
                trust on a Tuesday afternoon.
              </p>
              <p>
                I work as an AI/ML Engineer at Deloitte USI in Hyderabad, from 2024 through now. The stack
                stays close to the job: Python, LangChain, LangGraph, FastAPI, and the databases the
                business already keeps.
              </p>
            </div>
            <div>
              <p>
                Languages I write in: Python, Java, HTML, CSS, and JavaScript. Interfaces, when a person
                needs one, are in React. Services are FastAPI or Flask. The editors are Cursor and VS Code.
                The work moves through Git, GitHub, and Jira.
              </p>
              <p>
                Memory lives in MySQL, PostgreSQL, Couchbase Capella, vector databases, and knowledge
                graphs. Quality lives in Ragas and LangSmith — so a change can be measured before it is
                praised.
              </p>
            </div>
          </section>

          <hr className="rule" />
          <p className="mission">
            Ship work with <em>intention</em>
          </p>
          <nav className="footer-links" aria-label="Contact">
            <a href={`mailto:${profile.email}`}>Email</a>
            <a href={profile.github} target="_blank" rel="noreferrer">
              GitHub
            </a>
            <a href={profile.linkedin} target="_blank" rel="noreferrer">
              LinkedIn
            </a>
          </nav>
        </section>
      </main>
    </SiteFrame>
  );
}

function Spark() {
  return (
    <svg className="spark" viewBox="0 0 80 80" aria-hidden="true">
      <path
        d="M8 58c18-4 28-20 34-40"
        fill="none"
        stroke="#0f1111"
        strokeWidth="2.2"
        strokeLinecap="round"
      />
      <path d="M46 14l8 6-10 2 2-8z" fill="#0f1111" />
      <path d="M18 46l14-6" stroke="#0f1111" strokeWidth="2" strokeLinecap="round" />
      <circle cx="62" cy="22" r="2.2" fill="#0f1111" />
    </svg>
  );
}

function Dot({ light }: { light: boolean }) {
  return (
    <svg width="14" height="14" viewBox="0 0 14 14" aria-hidden="true">
      <circle cx="7" cy="7" r="5" fill="none" stroke={light ? "#111" : "#fff"} strokeWidth="1.4" />
      <circle cx="7" cy="7" r="1.4" fill={light ? "#111" : "#fff"} />
    </svg>
  );
}
